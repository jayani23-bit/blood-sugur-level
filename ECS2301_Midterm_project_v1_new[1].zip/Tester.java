import java.util.ArrayList;
import java.util.Scanner;

public class Tester {
    public static void main(String[] args) {
        BloodSugarApp bloodSugarApp = new BloodSugarApp();
        bloodSugarApp.displayMenu();
    }
}

class BloodSugar {
    private int id;
    private String name;
    private int yob;
    private int sugarLevel;

    public BloodSugar(int id, String name, int yob, int sugarLevel) {
        this.id = id;
        this.name = name;
        this.yob = yob;
        this.sugarLevel = sugarLevel;
    }

    public void display() {
        System.out.println("ID: " + getId());
        System.out.println("Name: " + getName());
        System.out.println("Year of Birth: " + getYob());
        System.out.println("Sugar Level: " + getSugarLevel());
        System.out.println("---------------------------");
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getYob() {
        return yob;
    }

    public void setYob(int yob) {
        this.yob = yob;
    }

    public int getSugarLevel() {
        return sugarLevel;
    }

    public void setSugarLevel(int sugarLevel) {
        this.sugarLevel = sugarLevel;
    }
}

class BloodSugarApp {
    private ArrayList<BloodSugar> records = new ArrayList<>();
    private Scanner scanner = new Scanner(System.in);

    public void displayMenu() {
        while (true) {
            System.out.println("Blood Sugar Monitoring System");
            System.out.println("1. Create a record");
            System.out.println("2. Show blood sugar data for all users");
            System.out.println("3. Show blood sugar data for a selected user");
            System.out.println("4. Delete all records");
            System.out.println("5. Exit application");

            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (choice) {
                case 1:
                    create();
                    
                    break;
                case 2:
                    index();
                    break;
                case 3:
                    System.out.print("Enter user ID: ");
                    int userId = scanner.nextInt();
                    view(userId);
                    break;
                case 4:
                    delete();
                    break;
                case 5:
                    exit();
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    public void index() {
        System.out.println("All Blood Sugar Records:");
        for (BloodSugar record : records) {
            record.display();
        }
    }

    public void view(int id) {
        boolean found = false;
        for (BloodSugar record : records) {
            if (record.getId() == id) {
                record.display();
                found = true;
                break;
            }
        }
        if (!found) {
            System.out.println("Record not found for ID: " + id);
        }
    }

    public void create() {
        System.out.print("Enter user ID: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        System.out.print("Enter user name: ");
        String name = scanner.nextLine();

        System.out.print("Enter year of birth: ");
        int yob = scanner.nextInt();

        System.out.print("Enter blood sugar level: ");
        int sugarLevel = scanner.nextInt();

        BloodSugar newRecord = new BloodSugar(id, name, yob, sugarLevel);
        records.add(newRecord);
        System.out.println("Record created successfully.");
    }

    public void delete() {
        records.clear();
        System.out.println("All records deleted.");
    }

    public void exit() {
        System.exit(0);
    }
}